<!DOCTYPE html>
<html lang="en">
    

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eternal Ayurveda</title>
    <script src="js/app.js" defer></script>
    <link rel="icon" href="images/leaf.png">
    <link
        href="https://fonts.googleapis.com/css2?family=Cabin&family=Herr+Von+Muellerhoff&family=Poiret+One&family=Source+Sans+Pro:wght@700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <script src="https://unpkg.com/scrollreveal"></script>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
</head>

<body>
    <!-- HEADER -->
    <header>
        <div class="container">
            <nav class="navbar">
                <div class="menu-toggle">
                    <i class="fas fa-bars"></i>
                    <i class="fas fa-times"></i>
                </div>
            <a href="index.php" class="logo"><img src="images/logo2.png" alt="Logo"></a>
            </nav>
        </div>
    </header>

    <!-- HERO SECTION -->

    <section class="hero" id="hero">
        <div class="container">
            <h1 class="headline"><b>Infinite Well-Being</b></h1>
            <a href="#" class="btn btn-primary"><i class="fab fa-google-play"></i> Download App</a>
        </div>
    </section>

    <!-- STORY SECTION -->

    <section class="our-story">
        <div class="container">
            <div class="row">
                <div class="description padding-right animate-left">
                    <div class="global-headline">
                        <h2 class="sub-headline">
                            Discover
                        </h2>
                        <h3 class="headline headline-dark">Our Story</h3>
                        <div class="asterisk"><i class="fas fa-asterisk"></i></div>
                    </div>
                    <p>In the ancient lands of India, amidst the mystic whispers of nature, Ayurveda bloomed as an art of healing and harmony. 
                        Passed down through generations, this sacred wisdom embraces the holistic balance of body, mind, and spirit. 
                        Our Ayurvedic website unveils the secrets of age-old remedies and timeless practices, guiding seekers on a transformative 
                        journey towards holistic well-being and profound connection with nature. Immerse yourself in the embrace of Ayurveda, where 
                        ancient wisdom meets modern healing, and discover a path to true vitality and inner serenity.</p>
                </div>
                <div class="image animate-right">
                    <img class="story-img" src="images/ayup.jpg" alt="bread">
                </div>
            </div>
        </div>
    </section>

    <!-- ALWAYS FRESH -->
    <section class="always-fresh shared">
        <div class="container">
            <div class="global-headline">
                <div class="animate-top">
                    <h2 class="sub-headline">
                        Timeless
                    </h2>
                </div>
                <div class="animate-bottom">
                    <h3 class="headline headline-dark">Vitality</h3>
                </div>
            </div>
        </div>
    </section>

    <!-- MENU SECTION -->
    <section class="menu">
        <div class="container">
            <div class="row">
                <div class="image-group padding-right animate-left">
                    <img src="images/ayufea1.svg" alt="image">
                    <img src="images/ayufea2.svg" alt="image">
                    <img src="images/ayufea3.svg" alt="image">
                    <img src="images/ayufea4.svg" alt="image">
                </div>
                <div class="description animate-right">
                    <div class="global-headline">
                        <h2 class="sub-headline">
                            Nurturing
                        </h2>
                        <h3 class="headline headline-dark">Ayurveda</h3>
                        <div class="asterisk"><i class="fas fa-leaf"></i></div>
                    </div>
                    <p>Discover personalized Ayurvedic recommendations and a comprehensive allergy assessment on our platform. Access an extensive guide on herb usage and benefit from advanced herb leaf detection technology for accurate herbal identification. Experience the essence of Ayurveda with modern innovation – a holistic wellness journey awaits you!</p>

                </div>
            </div>
        </div>
    </section>

    <!-- BAKERS DELIGHT SECTION -->
    <section class="delight">
        <div class="container">
            <div class="row">
                <div class="description padding-right animate-left">
                    <div class="global-headline">
                        <h2 class="sub-headline">
                            Unlock
                        </h2>
                        <h3 class="headline headline-dark">Knowledge</h3>
                        <div class="asterisk"><i class="fas fa-leaf"></i></div>
                    </div>
                    <p>Explore our in-depth insights for Kshaya preparation, unlocking the secrets of this ancient remedy for your well-being. Empower yourself with knowledge and practical guidance for a balanced and enriched life!</p>
                </div>
                <div class="image-group animate-right">
                    <img class="animate-top" src="images/ayufea5.svg" alt="pie">
                    <img class="animate-bottom" src="images/ayufea6.svg" alt="cookie">
                </div>
            </div>
        </div>
    </section>

    <!-- TASTY SECTION -->
    <section class="tasty shared">
        <div class="container">
            <div class="global-headline">
                <div class="animate-top">
                    <h2 class="sub-headline">
                        Sacred
                    </h2>
                </div>
                <div class="animate-bottom">
                    <h3 class="headline headline-light">Healing</h3>
                </div>
            </div>
        </div>
    </section>

    
    <!-- BMI SECTION -->
<section class="bmi">
    <div class="container">
        <div class="row">
            <div class="bmi-info padding-right animate-left">
                <div class="global-headline">
                    <h2 class="sub-headline">
                        Explore
                    </h2>
                    <h3 class="headline headline-dark">BMI</h3>
                    <div class="asterisk"><i class="fas fa-leaf"></i></div>
                </div>
                <p>Body Mass Index (BMI) is a measure that uses your weight and height to determine if you have a healthy body weight.
                    BMI is not a direct measurement of body fat, but it can be an indicator of potential health risks.</p>
                <p>A BMI below 18.5 indicates you are underweight, between 18.5 and 24.9 indicates a normal weight, between 25
                    and 29.9 indicates overweight, and 30 or higher indicates obesity. However, it's essential to consult a healthcare
                    professional for a more accurate evaluation of your health.</p>
            </div>
            <div class="bmi-calculation animate-right">
                <h4>Calculate Your BMI</h4>
                <form id="bmi-form">
                    <div>
                        <label for="height">Height (cm):</label>
                        <input type="number" step="0.01" min="0" name="height" id="height" required>
                    </div>
                    <div>
                        <label for="weight">Weight (kg):</label>
                        <input type="number" step="0.01" min="0" name="weight" id="weight" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Calculate BMI</button>
                </form>
                <div id="bmi-result"></div>
            </div>
        </div>
    </div>
</section>



<script>
    const bmiForm = document.getElementById('bmi-form');
    const bmiResult = document.getElementById('bmi-result');

    bmiForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const height = parseFloat(bmiForm.height.value);
        const weight = parseFloat(bmiForm.weight.value);
        const bmi = calculateBMI(height, weight);
        const bmiCategory = getBMICategory(bmi);

        bmiResult.innerHTML = `<p>Your Body Mass Index (BMI) is: <strong>${bmi.toFixed(2)}</strong></p>
                               <p>Category: <strong>${bmiCategory}</strong></p>`;
    });

    function calculateBMI(height, weight) {
        return weight / ((height / 100) ** 2);
    }

    function getBMICategory(bmi) {
        if (bmi < 18.5) return 'Underweight';
        if (bmi >= 18.5 && bmi < 25) return 'Normal Weight';
        if (bmi >= 25 && bmi < 30) return 'Overweight';
        return 'Obese';
    }
</script>

<!-- NEARBY AYURVEDIC CENTERS SECTION -->
<section class="nearby-centers">
    <div class="container">
        <div class="global-headline">
            <div class="animate-top">
                <h2 class="sub-headline">
                    Find
                </h2>
            </div>
            <div class="animate-bottom">
                <h3 class="headline headline-dark">Nearby Centers</h3>
                <div class="asterisk"><i class="fas fa-leaf"></i></div>
            </div>
        </div>
        <div id="map" class="map"></div>
    </div>
</section>


<script>
    // Function to initialize the Leaflet map
    function initMap() {
        // Initialize the map with the center at a default location (e.g., New York City)
        const map = L.map('map').setView([40.7128, -74.0060], 10);

        // Add a tile layer to the map (you can use any other tile provider)
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

        // Use the browser's geolocation API to get the user's current location
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const userLocation = [position.coords.latitude, position.coords.longitude];

                    // Use dummy data for nearby Ayurvedic centers (replace this with your API)
                    const nearbyCenters = [
                        { name: 'Center 1', location: [40.7127, -74.0059] },
                        { name: 'Center 2', location: [40.7129, -74.0061] },
                        { name: 'Center 3', location: [40.7126, -74.0062] },
                    ];

                    // Add markers for nearby centers to the map
                    nearbyCenters.forEach((center) => {
                        L.marker(center.location).addTo(map).bindPopup(center.name);
                    });

                    // Set the map center to the user's location
                    map.setView(userLocation, 14);
                },
                (error) => {
                    console.error('Error getting user location:', error);
                }
            );
        } else {
            console.error('Geolocation is not supported by this browser.');
        }
    }

    // Call the initMap function when the document is ready
    document.addEventListener('DOMContentLoaded', initMap);
</script>



    <!-- FOOTER -->
    <footer>
        <div class="container">
            <div class="back-to-top">
                <a href="#hero"><i class="fas fa-chevron-up"></i></a>
            </div>
            <div class="footer__content">
                <div class="footer__content-about animate-top">
                    <h4>About Us</h4>
                    <div class="asterisk"><i class="fas fa-leaf"></i></div>
                    <p>Team 570: Techsheroes <br> Alekhya Gorugantu, Ananya Warior, Anushka Bodke <br> Niyati Mehta, Riddhi Arya, Siddhika Rai</p>
                </div>
                <div class="footer__content-divider animate-bottom">
                    <div class="social-media">
                        <h4>Follow Us</h4>
                        <ul class="social-icons">
                            <li>
                                <a href="https://www.facebook.com/">
                                    <i class="fab fa-facebook-f"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://twitter.com/login">
                                    <i class="fab fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://www.instagram.com/?hl=en">
                                    <i class="fab fa-instagram"></i>
                                </a>
                            </li>
                            <li>
                                <a href="https://in.pinterest.com/">
                                    <i class="fab fa-pinterest"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="newsletter-container">
                        <h4>Newsletter</h4>
                        <form name= "news" action="news.php" method="post" class="newsletter-form">
                            <div class="newsletter-form-box">
                                <input type="mail" name="new" class="newsletter-input" placeholder="Your email address...">
                                <button class="newsletter-btn" type="submit" onclick="ValidateEmail(document.news.new)">
                                    <i class="fas fa-envelope"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>

</html>
