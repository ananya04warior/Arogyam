<?php

$searchAilment = $_GET['searchAilment'];

$mysqli = new mysqli("localhost", "root", "Niyati123$", "ayurveda");

// Check the connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Use prepared statement to avoid SQL injection
$sql = "SELECT * FROM `ailment-herb` WHERE Ailment = ?";

$stmt = $mysqli->prepare($sql);

if ($stmt === false) {
    die("Prepare error: " . $mysqli->error);
}

// Bind the parameter to the prepared statement
$stmt->bind_param("s", $searchAilment);

// Execute the query
if ($stmt->execute() === false) {
    die("Query error: " . $stmt->error);
}

// Get the result
$result = $stmt->get_result();


$rows = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
}

header('Content-Type: application/json');
echo json_encode($rows);

$stmt->close();
$mysqli->close();
