package com.example.arogyam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class WellnessTipsActivity extends AppCompatActivity {

    private Button btnSkin, btnHair, btnBody, btnMind;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wellness_tips);
        getSupportActionBar().hide();

        setUpView();
        setUpOnclickListner();
    }

    private void setUpView() {
        btnSkin = findViewById(R.id.btnSkin);
        btnHair = findViewById(R.id.btnHair);
        btnBody = findViewById(R.id.btnBody);
        btnMind = findViewById(R.id.btnMind);
    }

    private void setUpOnclickListner() {

        btnSkin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WellnessTipsActivity.this, SkinActivity.class);
                startActivity(intent);

            }
        });

        btnHair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WellnessTipsActivity.this, HairActivity.class);
                startActivity(intent);

            }
        });

        btnBody.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WellnessTipsActivity.this, BodyActivty.class);
                startActivity(intent);

            }
        });

        btnMind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WellnessTipsActivity.this, MindActivity.class);
                startActivity(intent);

            }
        });

    }


}