package com.example.arogyam;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SearchSymptomsActivity extends AppCompatActivity {

    private Button btnCough, btnDiabetes, btnHeadache;
    private EditText etSearch;
    private RecyclerView rvHerbList;
    private HerbAdapter herbAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_symptoms);
        getSupportActionBar().hide();

        setUpView();
        setOnClickListner();
    }
    private void setUpView() {
        btnCough = findViewById(R.id.btnCough);
        btnHeadache = findViewById(R.id.btnHeadache);
        btnDiabetes = findViewById(R.id.btnDiabetes);
        etSearch = findViewById(R.id.et_search);
        rvHerbList = findViewById(R.id.rv_herbList);
    }
    private void setOnClickListner() {

        btnCough.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listHerbs("Cold/Cough");
            }
        });
        btnHeadache.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listHerbs("Headache");
            }
        });
        btnDiabetes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listHerbs("Diabetes");
            }
        });
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) { }
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String symptom = etSearch.getText().toString();
                listHerbs(symptom);
            }
            @Override
            public void afterTextChanged(Editable editable) { }
        });
    }

    private void listHerbs(String symptom) {

        List<HerbModal> herbList = new ArrayList<>();

        ApiServices apiServices = RetrofitClient.getRetrofitInstance().create(ApiServices.class);
        apiServices.getHerbList(symptom).enqueue(new Callback<List<HerbModal>>() {

            @Override
            public void onResponse(Call<List<HerbModal>> call, Response<List<HerbModal>> response) {
                List<HerbModal> data = response.body();
                Log.d("Response", new Gson().toJson(data));
                if (data != null && !data.isEmpty()) {
                    // Set up the RecyclerView with the data received
                    setUpRecyclerView(data);
                }
                Log.e("Data", "onResponse: "+ new Gson().toJson(data));
            }

            @Override
            public void onFailure(Call<List<HerbModal>> call, Throwable t) {
                Log.e("Data", "onFailure: " + t.getMessage());
                t.printStackTrace();
            }
        });
    }

    private void setUpRecyclerView(List<HerbModal> data) {
        herbAdapter = new HerbAdapter(data, new HerbAdapter.OpenHerb() {
            @Override
            public void onClickReport(HerbModal herbModal) {
                navigate(herbModal);
            }
        });
        rvHerbList.setLayoutManager(new LinearLayoutManager(this));
        rvHerbList.setHasFixedSize(true);
        rvHerbList.setAdapter(herbAdapter);
    }

    private void navigate(HerbModal herbModal) {
        Intent intent = new Intent(SearchSymptomsActivity.this, OpenHerb.class);
        intent.putExtra(AppConstant.HERB_DATA, herbModal);
        startActivity(intent);
    }


}