package com.example.arogyam;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputLayout;

public class BmiCalculation extends AppCompatActivity {

    private EditText etHeight, etWeight;
    private Button btnCalculate;
    private TextView tvResult,tvResultDisp;
    private TextInputLayout heightTextInputLayout, weightTextInputLayout;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_calculation);
        getSupportActionBar().hide();

        etHeight = findViewById(R.id.etHeight);
        etWeight = findViewById(R.id.etWeight);
        btnCalculate = findViewById(R.id.btnCalculate);
        tvResult = findViewById(R.id.tvResult);
        tvResultDisp = findViewById(R.id.tvResultDis);
        heightTextInputLayout = findViewById(R.id.textInputLayoutHeight);
        weightTextInputLayout = findViewById(R.id.textInputLayoutWeight);

        btnCalculate.setOnClickListener(v -> calculateBMI());

        // Add text change listeners to clear result when the user changes height or weight
        etHeight.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tvResult.setText("");
            }

            @Override
            public void afterTextChanged(Editable s) {

            }

        });

        etWeight.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                tvResult.setText("");
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
    }
    private void calculateBMI() {
        String heightStr = etHeight.getText().toString().trim();
        String weightStr = etWeight.getText().toString().trim();

        if (heightStr.isEmpty()) {
            heightTextInputLayout.setError("Please enter height");
            return;
        }

        if (weightStr.isEmpty()) {
            weightTextInputLayout.setError("Please enter weight");
            return;
        }

        double heightCm = Double.parseDouble(heightStr);
        double weightKg = Double.parseDouble(weightStr);

        // Convert height to meters
        double heightM = heightCm / 100.0;

        // Calculate BMI
        double bmi = weightKg / (heightM * heightM);

        // Display the result
        String result = String.format("Your BMI: %.2f", bmi);
        tvResult.setText(result);

        if(bmi<=25.0)
        {
            tvResultDisp.setText("You are healthy");
        }
        else if(bmi<=30.0)
        {
            tvResultDisp.setText("Overweight");
        }
        else
        {
            tvResultDisp.setText("Obese");
        }

        // Clear any previous errors
        heightTextInputLayout.setError(null);
        weightTextInputLayout.setError(null);
    }

}