package com.example.arogyam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class OpenHerb extends AppCompatActivity {

    private TextView tvsci, tvherb, tvAilment, tvRemedy;
    String herb, ailment, remedy, sci;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_herb);
        getSupportActionBar().hide();


        getIntentData();
        setUpView();
        setData();
    }

    private void getIntentData() {
        Intent intent = getIntent();
        HerbModal herbs = intent.getParcelableExtra(AppConstant.HERB_DATA);
        sci = herbs.getScientificName();
        herb = herbs.getCommonName();
        ailment = herbs.getAilment();
        remedy = herbs.getRemedy();
    }

    private void setUpView() {
        tvsci = findViewById(R.id.tv_sci);
        tvherb = findViewById(R.id.tv_herb);
        tvAilment = findViewById(R.id.tv_ailment);
        tvRemedy = findViewById(R.id.tv_remedy);

    }
    private void setData() {
        tvherb.setText(herb );
        tvsci.setText(" (" + sci + ")");
        tvAilment.setText("Remedy For : " + ailment);
        tvRemedy.setText(remedy);
    }


}