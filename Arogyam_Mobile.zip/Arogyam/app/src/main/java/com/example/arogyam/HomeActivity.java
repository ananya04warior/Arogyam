package com.example.arogyam;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.IdentityHashMap;

public class HomeActivity extends AppCompatActivity {

    private Button btnSearch, btnWellness, btnKashaya, btnBmi, btnIdentify;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getSupportActionBar().hide();

        setUpView();
        setOnClickListner();

    }

    private void setUpView() {
        btnSearch = findViewById(R.id.btnSearch);
        btnWellness = findViewById(R.id.btnWellness);
        btnKashaya = findViewById(R.id.btnKashaya);
        btnBmi = findViewById(R.id.btnBmi);
        btnIdentify = findViewById(R.id.btnIdentifyHerb);
    }

    private void setOnClickListner() {


        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, SearchSymptomsActivity.class);
                startActivity(intent);

            }
        });


        btnWellness.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, WellnessTipsActivity.class);
                startActivity(intent);

            }
        });


        btnKashaya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, KashayaActivity.class);
                startActivity(intent);

            }
        });

        btnBmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, BmiCalculation.class);
                startActivity(intent);

            }
        });

        btnIdentify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomeActivity.this, HerbIdentificationActivity.class);
                startActivity(intent);

            }
        });
    }
}