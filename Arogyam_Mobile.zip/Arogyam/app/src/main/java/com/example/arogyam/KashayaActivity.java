package com.example.arogyam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class KashayaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kashaya);
        getSupportActionBar().hide();
        LinearLayout linearLayout = findViewById(R.id.linearLayout);

        // Loop to find and set click listeners for each TextView in the GridLayout rows
        for (int i = 1; i <= 16; i++) {
            // Find the GridLayout for this row
            int gridLayoutId = getResources().getIdentifier("row" + i, "id", getPackageName());
            GridLayout gridLayout = findViewById(gridLayoutId);

            // Set click listeners for each TextView in the GridLayout row
            for (int j = 0; j < gridLayout.getChildCount(); j++) {
                View child = gridLayout.getChildAt(j);
                if (child instanceof TextView) {
                    final int linkNumber = (i - 1) * 2 + j + 1;
                    TextView textView = (TextView) child;
                    textView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            openLink(linkNumber);
                        }
                    });
                }
            }
        }
    }

    private void openLink(int linkNumber) {

        String[] links = {
                "https://www.ayurtimes.com/amruthotharam-kashayam/",
                "https://www.ayurtimes.com/aragwadhadi-kashayam-kwatham/",
                "https://www.ayurtimes.com/arjuna-ksheer-pak-arjuna-siddha-kshir/",
                "https://www.ayurtimes.com/ashtavargam-kashayam/",
                "https://www.ayurtimes.com/ashwagandha-arjuna-ksheer-pak/",
                "https://www.ayurtimes.com/bala-punarnavadi-kashayam/",
                "https://www.ayurtimes.com/balaguluchyadi-kashayam-kwatham/",
                "https://www.ayurtimes.com/balajeerakadi-kashayam/",
                "https://www.ayurtimes.com/brihat-panchamoola/",
                "https://www.ayurtimes.com/brihatyadi-kashayam/",
                "https://www.ayurtimes.com/chiruvilwadi-kashayam/",
                "https://www.ayurtimes.com/chitrakadi-kashayam/",
                "https://www.ayurtimes.com/dasamulakatutrayadi-kashayam/",
                "https://www.ayurtimes.com/dashmool-dashamoola-dashamula/",
                "https://www.ayurtimes.com/dhanwantharam-kashayam/",
                "https://www.ayurtimes.com/drakshadi-kashayam-kwatham/",
                "https://www.ayurtimes.com/guluchyadi-kashayam-guduchyadi-kashayam/",
                "https://www.ayurtimes.com/how-to-make-decoction/",
                "https://www.ayurtimes.com/indukantham-kashayam-kwatham-indukantam-syrup/",
                "https://www.ayurtimes.com/jamun-vinegar-jamun-sirka/",
                "https://www.ayurtimes.com/kashayam-kashaya-kwath-ayurvedic-decoctions/",
                "https://www.ayurtimes.com/kokilaksha-kashayam/",
                "https://www.ayurtimes.com/laghu-panchamoola/",
                "https://www.ayurtimes.com/maharasnadi-kwath-kadha-kashayam-quath/",
                "https://www.ayurtimes.com/mahasudarshan-kadha/",
                "https://www.ayurtimes.com/nisakathakadi-kashayam/",
                "https://www.ayurtimes.com/punarnavadi-kashayam-kwatham/",
                "https://www.ayurtimes.com/shadanga-paniya/",
                "https://www.ayurtimes.com/shankhpushpi-syrup-benefits-side-effects/",
                "https://www.ayurtimes.com/sukumaram-kashayam/",
                "https://www.ayurtimes.com/varanadi-kashayam-benefits-uses-dosage-side-effects/",
                "https://www.ayurtimes.com/kashayam-kwath-list/"
        };

        if (linkNumber > 0 && linkNumber <= links.length) {
            String url = links[linkNumber - 1];
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        }
    }
}