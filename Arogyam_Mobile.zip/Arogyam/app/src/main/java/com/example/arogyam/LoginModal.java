package com.example.arogyam;

public class LoginModal {
}
