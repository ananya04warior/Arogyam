package com.example.arogyam;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HerbAdapter extends RecyclerView.Adapter<HerbAdapter.ViewHolder> {


    private List<HerbModal> herbList;
    private OpenHerb openHerb;

    public HerbAdapter() {
    }

    public HerbAdapter(List<HerbModal> herbList, OpenHerb openHerb) {
        this.herbList = herbList;
        this.openHerb = openHerb;
    }



    @NonNull
    @Override
    public HerbAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.activity_herb_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HerbModal herbModal = herbList.get(position);
        holder.commonName.setText(herbModal.getCommonName());

        holder.commonName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (openHerb != null) {
                    openHerb.onClickReport(herbModal);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
       return herbList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView commonName;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            commonName = itemView.findViewById(R.id.tv_commonName);
        }
    }

    interface OpenHerb {

        void onClickReport(HerbModal HerbModal);

    }
}
