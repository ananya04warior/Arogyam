package com.example.arogyam;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefUtils {
    private static final String PREF_APP = "pref_app";
    private final SharedPreferences sharedPref;

    private static SharedPrefUtils instance;

    public static synchronized SharedPrefUtils getInstance(Context applicationContext){
        if(instance == null)
            instance = new SharedPrefUtils(applicationContext);
        return instance;
    }

    private SharedPrefUtils(Context applicationContext) {
        sharedPref = applicationContext.getSharedPreferences(
                "user_data", Context.MODE_PRIVATE);
    }

    public void writeStringData(String key, String value) {
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString(key, value);
        editor.apply();
    }

    public String readStringData(String key) {
        return sharedPref.getString(key, "");
    }

    public void writeBooleanData(String key, boolean value) {
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    public boolean readBooleanData(String key) {
        return sharedPref.getBoolean(key, false);
    }
}
