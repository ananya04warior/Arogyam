package com.example.arogyam;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BodyActivty extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_body_activty);
        getSupportActionBar().hide();

    }
}