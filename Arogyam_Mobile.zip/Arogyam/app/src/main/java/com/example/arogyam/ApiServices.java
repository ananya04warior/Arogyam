package com.example.arogyam;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface ApiServices {

    @GET("fetch.php")
    Call<List<HerbModal>> getHerbList(@Query("searchAilment") String searchAilment);

}
