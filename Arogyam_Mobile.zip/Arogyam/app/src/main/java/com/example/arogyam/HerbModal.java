package com.example.arogyam;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class HerbModal implements Parcelable {

    @SerializedName("Ailment")
    @Expose
    private String ailment;

    @SerializedName("Scientific Name")
    @Expose
    private String scientificName;

    @SerializedName("Common Name")
    @Expose
    private String commonName;

    @SerializedName("Remedy")
    @Expose
    private String remedy;

    public HerbModal() {
    }

    public HerbModal(String ailment, String scientificName, String commonName, String remedy) {
        this.ailment = ailment;
        this.scientificName = scientificName;
        this.commonName = commonName;
        this.remedy = remedy;
    }


    protected HerbModal(Parcel in) {
        ailment = in.readString();
        scientificName = in.readString();
        commonName = in.readString();
        remedy = in.readString();
    }

    public static final Creator<HerbModal> CREATOR = new Creator<HerbModal>() {
        @Override
        public HerbModal createFromParcel(Parcel in) {
            return new HerbModal(in);
        }

        @Override
        public HerbModal[] newArray(int size) {
            return new HerbModal[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(ailment);
        dest.writeString(scientificName);
        dest.writeString(commonName);
        dest.writeString(remedy);
    }

    public String getAilment() {
        return ailment;
    }

    public void setAilment(String ailment) {
        this.ailment = ailment;
    }

    public String getScientificName() {
        return scientificName;
    }

    public void setScientificName(String scientificName) {
        this.scientificName = scientificName;
    }

    public String getCommonName() {
        return commonName;
    }

    public void setCommonName(String commonName) {
        this.commonName = commonName;
    }

    public String getRemedy() {
        return remedy;
    }

    public void setRemedy(String remedy) {
        this.remedy = remedy;
    }
}

