package com.example.arogyam;

public class AppConstant {
    public static String HERB_DATA = "HERB_DATA";
    public static String IS_LOGIN = "IS_LOGIN";
}
